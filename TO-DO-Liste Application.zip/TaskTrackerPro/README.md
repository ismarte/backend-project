# TO-DO List Application

A complete full-stack TypeScript task management application with React frontend and Express.js backend.

## Features

- **Complete CRUD Operations**: Create, read, update, and delete tasks
- **Task Management**: Set priorities (low, medium, high), due dates, and completion status
- **Advanced Filtering**: Filter tasks by status (all, active, completed) and search functionality
- **Task Statistics**: Real-time dashboard showing completion progress
- **Responsive Design**: Modern UI with Tailwind CSS and shadcn/ui components
- **Type Safety**: Full TypeScript implementation with shared schemas

## Tech Stack

### Frontend
- React 18 with TypeScript
- Vite for fast development and building
- Tailwind CSS for styling
- shadcn/ui component library
- TanStack Query for server state management
- React Hook Form with Zod validation
- Wouter for routing

### Backend
- Express.js with TypeScript
- In-memory storage for development
- Zod for request validation
- RESTful API design

## Getting Started

### Prerequisites
- Node.js 20 or later
- npm or yarn

### Installation

1. Install dependencies:
```bash
npm install
```

2. Start the development server:
```bash
npm run dev
```

This will start both the frontend and backend servers. The application will be available at `http://localhost:5000`.

### Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run start` - Start production server
- `npm run db:push` - Push database schema changes (when using PostgreSQL)

## API Endpoints

- `GET /api/tasks` - Get all tasks
- `GET /api/tasks/:id` - Get specific task
- `POST /api/tasks` - Create new task
- `PUT /api/tasks/:id` - Update existing task
- `DELETE /api/tasks/:id` - Delete task
- `GET /api/tasks/status/:completed` - Get tasks by completion status

## Database Configuration

The application uses in-memory storage by default for development. For production, set the `DATABASE_URL` environment variable to use PostgreSQL with Neon Database.

## Project Structure

```
├── client/          # React frontend
│   ├── src/
│   │   ├── components/  # Reusable components
│   │   ├── pages/       # Page components
│   │   ├── hooks/       # Custom hooks
│   │   └── lib/         # Utilities
├── server/          # Express backend
│   ├── index.ts     # Server entry point
│   ├── routes.ts    # API routes
│   └── storage.ts   # Data storage layer
├── shared/          # Shared types and schemas
└── package.json     # Dependencies and scripts
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is open source and available under the [MIT License](LICENSE).