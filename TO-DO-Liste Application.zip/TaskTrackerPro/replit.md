# Task Management Application

## Overview

This is a full-stack TypeScript task management application built with React frontend and Express backend. The application provides a modern, responsive interface for creating, managing, and tracking tasks with features like filtering, search, and priority management.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Build Tool**: Vite for fast development and building
- **Styling**: Tailwind CSS with custom design system
- **UI Components**: Radix UI primitives with custom shadcn/ui components
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Form Management**: React Hook Form with Zod validation

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Validation**: Zod schemas shared between frontend and backend
- **API Pattern**: RESTful API with proper error handling
- **Development Storage**: In-memory storage fallback for development

## Key Components

### Database Schema
- **Tasks Table**: Core entity with fields for title, description, priority, completion status, due date, and timestamps
- **Users Table**: Basic user structure (prepared for future authentication)
- **Shared Types**: TypeScript types generated from Drizzle schema

### API Endpoints
- `GET /api/tasks` - Retrieve all tasks
- `GET /api/tasks/:id` - Retrieve specific task
- `POST /api/tasks` - Create new task
- `PUT /api/tasks/:id` - Update existing task
- `DELETE /api/tasks/:id` - Delete task

### Frontend Components
- **TaskForm**: Form for creating new tasks with validation
- **TaskList**: Display and manage existing tasks
- **TaskFilters**: Filter tasks by status and search functionality
- **TaskStats**: Dashboard showing task completion statistics
- **EditTaskModal**: Modal for editing existing tasks
- **DeleteConfirmationModal**: Confirmation dialog for task deletion

### UI System
- **Design System**: Custom theme with CSS variables for consistent styling
- **Component Library**: Comprehensive set of reusable UI components
- **Responsive Design**: Mobile-first approach with breakpoint-based layouts
- **Accessibility**: ARIA-compliant components with keyboard navigation

## Data Flow

1. **Task Creation**: User submits form → Frontend validation → API call → Database storage → UI update
2. **Task Retrieval**: Component mount → TanStack Query fetch → API endpoint → Database query → UI rendering
3. **Task Updates**: User interaction → Optimistic updates → API call → Database update → Query invalidation
4. **Real-time Updates**: Query invalidation triggers automatic refetching for consistent state

## External Dependencies

### Core Dependencies
- **Database**: Neon Database (serverless PostgreSQL)
- **ORM**: Drizzle ORM for type-safe database operations
- **UI Components**: Radix UI for accessible component primitives
- **Icons**: Lucide React for consistent iconography
- **Date Handling**: date-fns for date manipulation and formatting

### Development Tools
- **TypeScript**: Full type safety across the stack
- **ESBuild**: Fast bundling for production builds
- **Vite**: Development server with hot module replacement
- **Tailwind CSS**: Utility-first CSS framework

## Deployment Strategy

### Build Process
1. **Frontend Build**: Vite bundles React application to `dist/public`
2. **Backend Build**: ESBuild compiles TypeScript server to `dist/index.js`
3. **Database Migration**: Drizzle Kit handles schema migrations

### Environment Configuration
- **Development**: Uses in-memory storage and Vite dev server
- **Production**: Requires `DATABASE_URL` environment variable for PostgreSQL connection
- **Database**: Configured for PostgreSQL with automatic migration support

### Scripts
- `npm run dev` - Start development server with hot reload
- `npm run build` - Build both frontend and backend for production
- `npm run start` - Start production server
- `npm run db:push` - Push database schema changes

## Changelog

```
Changelog:
- July 05, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```