import { useState } from "react";
import TaskForm from "@/components/task-form";
import TaskList from "@/components/task-list";
import TaskFilters from "@/components/task-filters";
import TaskStats from "@/components/task-stats";
import EditTaskModal from "@/components/edit-task-modal";
import DeleteConfirmationModal from "@/components/delete-confirmation-modal";
import { ListTodo } from "lucide-react";
import type { Task } from "@shared/schema";

type FilterType = "all" | "active" | "completed";

export default function TasksPage() {
  const [filter, setFilter] = useState<FilterType>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [deletingTaskId, setDeletingTaskId] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
                <ListTodo className="text-white" size={16} />
              </div>
              <h1 className="text-xl font-semibold text-slate-900">TaskFlow</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <TaskStats />
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <TaskForm />
        
        <TaskFilters
          filter={filter}
          onFilterChange={setFilter}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
        />
        
        <TaskList
          filter={filter}
          searchQuery={searchQuery}
          onEditTask={setEditingTask}
          onDeleteTask={setDeletingTaskId}
        />
      </main>

      {/* Modals */}
      <EditTaskModal
        task={editingTask}
        onClose={() => setEditingTask(null)}
      />
      
      <DeleteConfirmationModal
        taskId={deletingTaskId}
        onClose={() => setDeletingTaskId(null)}
      />
    </div>
  );
}
