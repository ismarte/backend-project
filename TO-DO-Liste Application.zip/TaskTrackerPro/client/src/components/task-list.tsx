import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, Edit, Trash2, CheckCircle } from "lucide-react";
import type { Task } from "@shared/schema";

type FilterType = "all" | "active" | "completed";

interface TaskListProps {
  filter: FilterType;
  searchQuery: string;
  onEditTask: (task: Task) => void;
  onDeleteTask: (taskId: number) => void;
}

export default function TaskList({
  filter,
  searchQuery,
  onEditTask,
  onDeleteTask,
}: TaskListProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: tasks = [], isLoading } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const toggleTaskMutation = useMutation({
    mutationFn: async ({ id, completed }: { id: number; completed: boolean }) => {
      const response = await apiRequest("PUT", `/api/tasks/${id}`, { completed });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update task",
        variant: "destructive",
      });
    },
  });

  const filteredTasks = tasks.filter(task => {
    const matchesFilter = 
      filter === "all" ||
      (filter === "active" && !task.completed) ||
      (filter === "completed" && task.completed);
    
    const matchesSearch = !searchQuery || 
      task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.description?.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesFilter && matchesSearch;
  });

  const handleToggleTask = (task: Task) => {
    toggleTaskMutation.mutate({ id: task.id, completed: !task.completed });
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-700";
      case "medium":
        return "bg-amber-100 text-amber-700";
      case "low":
        return "bg-slate-100 text-slate-700";
      default:
        return "bg-slate-100 text-slate-700";
    }
  };

  const formatDate = (date: Date | string) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <div className="animate-pulse">
              <div className="h-4 bg-slate-200 rounded w-3/4 mb-2"></div>
              <div className="h-3 bg-slate-200 rounded w-1/2"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (filteredTasks.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-12 text-center">
        <div className="text-slate-400 mb-4">
          <CheckCircle size={48} className="mx-auto" />
        </div>
        <h3 className="text-lg font-semibold text-slate-900 mb-2">No tasks found</h3>
        <p className="text-slate-600">
          {searchQuery 
            ? "No tasks match your search criteria."
            : filter === "all" 
              ? "Create your first task to get started!"
              : `No ${filter} tasks available.`
          }
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {filteredTasks.map((task) => (
        <div
          key={task.id}
          className={`bg-white rounded-xl shadow-sm border border-slate-200 hover:shadow-md transition-shadow ${
            task.completed ? "opacity-75" : ""
          }`}
        >
          <div className="p-6">
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-4 flex-1">
                <div className="flex-shrink-0 pt-1">
                  <Checkbox
                    checked={task.completed}
                    onCheckedChange={() => handleToggleTask(task)}
                    disabled={toggleTaskMutation.isPending}
                  />
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2 mb-2">
                    <h3 className={`text-base font-semibold text-slate-900 ${
                      task.completed ? "line-through" : ""
                    }`}>
                      {task.title}
                    </h3>
                    <Badge className={`${getPriorityColor(task.priority)} text-xs`}>
                      {task.completed ? "Completed" : `${task.priority.charAt(0).toUpperCase() + task.priority.slice(1)} Priority`}
                    </Badge>
                  </div>
                  
                  {task.description && (
                    <p className={`text-sm text-slate-600 mb-3 ${
                      task.completed ? "line-through" : ""
                    }`}>
                      {task.description}
                    </p>
                  )}
                  
                  <div className="flex items-center space-x-4 text-xs text-slate-500">
                    {task.dueDate && (
                      <span className="flex items-center space-x-1">
                        <Calendar size={12} />
                        <span>Due: {formatDate(task.dueDate)}</span>
                      </span>
                    )}
                    
                    {task.completed ? (
                      <span className="flex items-center space-x-1">
                        <CheckCircle size={12} className="text-emerald-500" />
                        <span>Completed: {formatDate(task.updatedAt)}</span>
                      </span>
                    ) : (
                      <span className="flex items-center space-x-1">
                        <Clock size={12} />
                        <span>Created: {formatDate(task.createdAt)}</span>
                      </span>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="flex items-center space-x-2 ml-4">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onEditTask(task)}
                  className="text-slate-400 hover:text-blue-600"
                >
                  <Edit size={16} />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onDeleteTask(task.id)}
                  className="text-slate-400 hover:text-red-600"
                >
                  <Trash2 size={16} />
                </Button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
