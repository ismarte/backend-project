import { useQuery } from "@tanstack/react-query";
import type { Task } from "@shared/schema";

export default function TaskStats() {
  const { data: tasks = [] } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(task => task.completed).length;
  const pendingTasks = totalTasks - completedTasks;
  const completionPercentage = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  return (
    <div className="mt-8 bg-white rounded-xl shadow-sm border border-slate-200 p-6">
      <h3 className="text-lg font-semibold text-slate-900 mb-4">Task Statistics</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="text-center">
          <div className="text-3xl font-bold text-blue-600">{totalTasks}</div>
          <div className="text-sm text-slate-600">Total Tasks</div>
        </div>
        <div className="text-center">
          <div className="text-3xl font-bold text-emerald-600">{completedTasks}</div>
          <div className="text-sm text-slate-600">Completed</div>
        </div>
        <div className="text-center">
          <div className="text-3xl font-bold text-amber-600">{pendingTasks}</div>
          <div className="text-sm text-slate-600">Pending</div>
        </div>
      </div>
      
      <div className="mt-4">
        <div className="flex justify-between text-sm text-slate-600 mb-2">
          <span>Progress</span>
          <span>{completionPercentage}%</span>
        </div>
        <div className="w-full bg-slate-200 rounded-full h-2">
          <div 
            className="bg-blue-600 h-2 rounded-full transition-all duration-300" 
            style={{ width: `${completionPercentage}%` }}
          />
        </div>
      </div>
    </div>
  );
}
