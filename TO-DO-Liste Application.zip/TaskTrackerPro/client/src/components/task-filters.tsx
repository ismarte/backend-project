import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { Task } from "@shared/schema";

type FilterType = "all" | "active" | "completed";

interface TaskFiltersProps {
  filter: FilterType;
  onFilterChange: (filter: FilterType) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

export default function TaskFilters({
  filter,
  onFilterChange,
  searchQuery,
  onSearchChange,
}: TaskFiltersProps) {
  const { data: tasks = [] } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const allCount = tasks.length;
  const activeCount = tasks.filter(task => !task.completed).length;
  const completedCount = tasks.filter(task => task.completed).length;

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 mb-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
        <div className="flex items-center space-x-1">
          <Button
            variant={filter === "all" ? "default" : "ghost"}
            size="sm"
            onClick={() => onFilterChange("all")}
            className={filter === "all" ? "bg-blue-50 text-blue-600 hover:bg-blue-100" : ""}
          >
            All Tasks
            <span className="ml-2 px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-xs">
              {allCount}
            </span>
          </Button>
          
          <Button
            variant={filter === "active" ? "default" : "ghost"}
            size="sm"
            onClick={() => onFilterChange("active")}
            className={filter === "active" ? "bg-blue-50 text-blue-600 hover:bg-blue-100" : ""}
          >
            Active
            <span className="ml-2 px-2 py-1 bg-slate-100 text-slate-600 rounded-full text-xs">
              {activeCount}
            </span>
          </Button>
          
          <Button
            variant={filter === "completed" ? "default" : "ghost"}
            size="sm"
            onClick={() => onFilterChange("completed")}
            className={filter === "completed" ? "bg-blue-50 text-blue-600 hover:bg-blue-100" : ""}
          >
            Completed
            <span className="ml-2 px-2 py-1 bg-slate-100 text-slate-600 rounded-full text-xs">
              {completedCount}
            </span>
          </Button>
        </div>
        
        <div className="flex items-center space-x-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" size={16} />
            <Input
              placeholder="Search tasks..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <Select>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Sort by Date" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="date">Sort by Date</SelectItem>
              <SelectItem value="priority">Sort by Priority</SelectItem>
              <SelectItem value="status">Sort by Status</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
}
