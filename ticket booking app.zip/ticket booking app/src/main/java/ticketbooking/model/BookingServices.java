package ticketbooking.model;


import com.example.ticketbooking.repository.BookingRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class Bookingservice {

    private final BookingRepository bookingRepository;

    public BookingServices(BookingRepository bookingRepository) {
        this.bookingRepository = bookingRepository;
    }

    public Booking createBooking(Booking booking) {
        return bookingRepository.save(booking);
    }

    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    public Optional<Booking> getBookingById(Long id) {
        return bookingRepository.findById(id);
    }

    public Booking updateBooking(Long id, Booking updatedBooking) {
        return bookingRepository.findById(id).map(booking -> {
            booking.setEmail(updatedBooking.getEmail());
            booking.setFirstName(updatedBooking.getFirstName());
            booking.setLastName(updatedBooking.getLastName());
            booking.setAddress(updatedBooking.getAddress());
            booking.setPhone(updatedBooking.getPhone());
            booking.setBookingDateTime(updatedBooking.getBookingDateTime());
            return bookingRepository.save(booking);
        }).orElseThrow(() -> new RuntimeException("Booking not found with id " + id));
    }

    public void deleteBooking(Long id) {
        bookingRepository.deleteById(id);
    }
}

