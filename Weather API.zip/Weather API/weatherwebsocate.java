package com.example.weatherapi.controller;

import com.example.weatherapi.dto.WeatherResponse;
import com.example.weatherapi.service.WeatherService;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

@Controller
public class WebSocketController {
    private final WeatherService weatherService;

    public WebSocketController(WeatherService weatherService) {
        this.weatherService = weatherService;
    }

    @MessageMapping("/request-weather")
    @SendTo("/topic/weather-updates")
    public WeatherResponse sendWeatherUpdate(String city) {
        return weatherService.getWeatherData(city);
    }
}