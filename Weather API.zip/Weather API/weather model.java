package com.example.weatherapi.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Entity
@Data
public class Weather {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String city;
    
    private Double temperature;
    private Double humidity;
    private String conditions;
    private LocalDateTime timestamp = LocalDateTime.now();
}