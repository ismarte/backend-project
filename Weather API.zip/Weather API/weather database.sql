CREATE DATABASE weatherdb;
CREATE USER postgres WITH PASSWORD 'yourpassword';
GRANT ALL PRIVILEGES ON DATABASE weatherdb TO postgres;