package com.example.weatherapi.service;

import com.example.weatherapi.dto.WeatherResponse;
import com.example.weatherapi.exception.WeatherServiceException;
import com.example.weatherapi.model.Weather;
import com.example.weatherapi.repository.WeatherRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class WeatherService {
    private final WeatherRepository weatherRepository;
    private final RestTemplate restTemplate;

    @Value("${weather.api.key}")
    private String apiKey;

    @Value("${weather.api.url}")
    private String apiUrl;

    public WeatherResponse getWeatherData(String city) {
        // Check for recent data in DB (within last 10 minutes)
        Optional<Weather> recentWeather = weatherRepository.findTopByCityOrderByTimestampDesc(city);
        if (recentWeather.isPresent() && 
            recentWeather.get().getTimestamp().isAfter(LocalDateTime.now().minus(10, ChronoUnit.MINUTES))) {
            return convertToResponse(recentWeather.get());
        }

        // Fetch from external API
        try {
            String url = String.format("%s?q=%s&appid=%s&units=metric", apiUrl, city, apiKey);
            Map<String, Object> response = restTemplate.getForObject(url, Map.class);
            
            if (response == null || response.containsKey("cod") && !response.get("cod").equals(200)) {
                throw new WeatherServiceException("Failed to fetch weather data: " + 
                    (response != null ? response.get("message") : "No response"));
            }

            Map<String, Object> main = (Map<String, Object>) response.get("main");
            Map<String, Object> weather = (Map<String, Object>) ((java.util.List<?>) response.get("weather")).get(0);

            // Save to database
            Weather newWeather = new Weather();
            newWeather.setCity(city);
            newWeather.setTemperature(Double.parseDouble(main.get("temp").toString()));
            newWeather.setHumidity(Double.parseDouble(main.get("humidity").toString()));
            newWeather.setConditions(weather.get("description").toString());
            weatherRepository.save(newWeather);

            return convertToResponse(newWeather);
        } catch (Exception e) {
            throw new WeatherServiceException("Error fetching weather data: " + e.getMessage(), e);
        }
    }

    private WeatherResponse convertToResponse(Weather weather) {
        return new WeatherResponse(
            weather.getCity(),
            weather.getTemperature(),
            weather.getHumidity(),
            weather.getConditions()
        );
    }
}