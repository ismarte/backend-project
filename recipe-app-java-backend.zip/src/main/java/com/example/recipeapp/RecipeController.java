package com.example.recipeapp;

import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.ArrayList;

@RestController
@RequestMapping("/recipes")
public class RecipeController {

    @GetMapping
    public List<String> getAllRecipes() {
        List<String> recipes = new ArrayList<>();
        recipes.add("Avocado Toast");
        recipes.add("Caesar Salad");
        return recipes;
    }
}
